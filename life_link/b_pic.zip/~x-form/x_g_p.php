<? 
require_once('Connections/sc.php');mysql_query("set names utf8");
require_once( dirname(dirname(__FILE__)) .'/class/queue.class.php' );
require_once( 'is_out.php' );
require_once( 'Promotions.php' );
require_once( 'Reservoir.php');


session_start();
ob_start();
date_default_timezone_set('Asia/Taipei');
$year=date("Y");$moom=date("m");$day=date("d");$z=date("z");$date=date("Y-m-d");$time=date("H:i:s");
$sn=$_POST['sn'];//echo $sn;exit;
if ($sn == "") {header(sprintf("Location: /cmg/life_link/index.php"));exit;}
mysql_select_db($database_sc, $sc);

$query_Recsn = sprintf("SELECT * FROM memberdata WHERE number = '$sn' && m_ok >= 1");//
$Recsn = mysql_query($query_Recsn, $sc) or die(mysql_error());
$row_Recsn = mysql_fetch_assoc($Recsn);
$totalRows_Recsn = mysql_num_rows($Recsn);
if ($totalRows_Recsn == 0) {header(sprintf("Location: /cmg/life_link/index.php"));exit;}
$name=$row_Recsn['m_name'];
$nick=$row_Recsn['m_nick'];
$card=$row_Recsn['card'];?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<div id="divLoading" style="color:red; position:absolute; top:166px; left:703px;">

<img src="http://cmg588.com/life_link/ajax-loader.gif" border="0" style="vertical-align:middle;padding:6px"/>



</div>

<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">

  <tr>
    <td height="100" align="center">&nbsp;</td>
  </tr>
  <tr>

    <td align="center">運算資訊中，請勿關閉或動任何行為…，請稍候...</td>

  </tr>

  <tr>

    <td align="center">進度： 準備開始</td>

  </tr>

</table>

<?php 
	$ter=$_POST['ter'];$fuser=$_POST['fuser'];$fnumber=$_POST['fnumber'];$newuser=$_POST['newuser'];$m_passwd=$_POST['m_passwd'];$m_passtoo=$_POST['m_passtoo'];$mok=1;

	$coc=$_POST['coc'];$m_sex=$_POST['m_sex'];$m_birthday=$_POST['birthday'];$m_callphone=$_POST['m_callphone'];$m_email=$_POST['m_email'];$m_nick=$_POST['m_nick'];$Tnumber=$_POST['Tnumber'];

	$pudid=$_POST['pudid'];$pud_p=$_POST['pud_p'];$pud_n=$_POST['pud_n'];$snumber=$_POST['snumber'];$b_pud=$_POST['b_pud']+0;
    $as_at=$_POST['as_at'];$as_number=$_POST['as_number'];$as_name=$_POST['as_name'];$notpay =$_POST["notpay"];
	mysql_select_db($database_sc, $sc);//echo "###",$pudid;exit;

    $query_Recapud = sprintf("SELECT * FROM a_pud WHERE id='$pudid'");// 

    $Recapud = mysql_query($query_Recapud, $sc) or die(mysql_error());

    $row_Recapud = mysql_fetch_assoc($Recapud);

	$totalRows_Recapud = mysql_num_rows($Recapud);
	$pud_p = $row_Recapud['af'];

	$apud_a1=$row_Recapud['fpay1'];
	$apud_a2=$row_Recapud['fpay2'];
	$apud_a=$row_Recapud['p'];
	$apud_b=$row_Recapud['b'];
	$apud_c=$row_Recapud['c'];
	$apud_d=$row_Recapud['d'];
	$apud_e=$row_Recapud['e'];
	$apud_f=$row_Recapud['f'];
	$apud_da=$row_Recapud['d_a'];
	$apud_db=$row_Recapud['d_b'];
	$apud_dc=$row_Recapud['d_c'];
	$apud_dd=$row_Recapud['d_d'];
	$pud_name = $row_Recapud['name'];
	//

	$date=date("Y-m-d");$time=date("H:i:s");$year=date("Y");$moom=date("m");$day=date("d");$z=date("z");

	

	//-ocash
	
	

	//-b_pud (目前無用)

	if ($b_pud != 0) {

		mysql_select_db($database_sc, $sc);

		$query_Recb = sprintf("SELECT * FROM b_pud WHERE id='$b_pud'");

		$Recb = mysql_query($query_Recb, $sc) or die(mysql_error());

		$row_Recb = mysql_fetch_assoc($Recb);

		$totalRows_Recb = mysql_num_rows($Recb);

		$pud_bp=$row_Recb['p'];

		//

		mysql_select_db($database_sc, $sc);

		$query_Recob = sprintf("SELECT * FROM o_cash WHERE number='$snumber' ORDER BY id DESC");// 

		$Recob = mysql_query($query_Recob, $sc) or die(mysql_error());

		$row_Recob = mysql_fetch_assoc($Recob);

		$totalRows_Recob = mysql_num_rows($Recob);

		if ($row_Recob['csum'] >= $pud_bp) {

			$new_ob=$row_Recob['csum']-$pud_bp;

			$onote=$newuser."註冊加購商品扣值, <br/>品名：".$row_Recb['name'];

			mysql_select_db($database_sc, $sc);

			$insertCommand13="INSERT INTO o_cash (number, cout, csum, note, date, time) VALUES ('$snumber', '$pud_bp', '$new_ob', '$onote', '$date', '$time')"; 

			mysql_query($insertCommand13,$sc);

			} else {

				header(sprintf("Location: /cmg/life_link/new_account-1.php?err=我的註冊積分不足"));

				exit;

				}

	}
	///
	//number

	mysql_select_db($database_sc, $sc);$bo="boss";

    $query_Reci = sprintf("SELECT * FROM admin WHERE username='$bo'");

    $Reci = mysql_query($query_Reci, $sc) or die(mysql_error());

    $row_Reci = mysql_fetch_assoc($Reci);

    $num_box=$row_Reci['num_box'];

    $num_z=$row_Reci['num_z'];

    if(date("m") != $num_z) {

	   $numz=date("m");

	   $update11="UPDATE admin SET num_z='$numz' WHERE username='$bo'";

       mysql_select_db($database_sc, $sc);

       $Result11 = mysql_query($update11, $sc) or die(mysql_error());

	   $num_box=1;

	   }

    if ($num_box == 10000) {echo "設定值巳超過9999單號，請洽系統工程師。";exit;}

    if ($num_box < 10) {$number="SN".date("ymd")."000".$num_box;$card=date("ym")."000".$num_box;}

    if ($num_box > 9 && $num_box < 100) {$number="SN".date("ymd")."00".$num_box;$card=date("ym")."00".$num_box;}

    if ($num_box < 1000 && $num_box > 99) {$number="SN".date("ymd")."0".$num_box;$card=date("ym")."0".$num_box;}

	if ($num_box < 10000 && $num_box > 999) {$number="SN".date("ymd").$num_box;$card=date("ym").$num_box;}

	$new_num_box=$num_box+1;

    $update11="UPDATE admin SET num_box='$new_num_box' WHERE username='$bo'";

    mysql_select_db($database_sc, $sc);

    $Result11 = mysql_query($update11, $sc) or die(mysql_error());

	//

	mysql_select_db($database_sc, $sc);

    $insertCommand3="INSERT INTO memberdata (fname, m_nick, card, m_username, m_passwd, m_passtoo, number, m_fuser, a_pud, b_pud, ks, m_ok, year, moom, day, z, m_sex, m_email, m_joinDate, m_callphone, st, date, time, fpay, as_at, as_number, as_name) VALUES ('$fuser', '$m_nick', '$card', '$newuser', '$m_passwd', '$m_passtoo', '$number', '$fnumber', '$pudid', '$b_pud', '$pud_p', '$mok', '$year', '$moom', '$day', '$z', '$m_sex', '$m_email', '$date', '$m_callphone', '$st', '$date', '$time', '$fpay', '$as_at', '$as_number', '$as_name')"; 

    mysql_query($insertCommand3,$sc);

	if(!empty($notpay))
	{	//特殊入單  未繳費  扣積分總庫
		
			
		mysql_select_db($database_sc, $sc);

		$onote="註冊扣值(".$pud_n.")<br/>帳號：".$newuser;
		$notpay_c ="-".$notpay;
		$sncode=$number."-".date("ymdhis");
		
		$query_Recob = sprintf("SELECT * FROM o_cash WHERE number='$snumber' ORDER BY id DESC");// 
		$Recob = mysql_query($query_Recob, $sc) or die(mysql_error());
		$row_Recob = mysql_fetch_assoc($Recob);
		$totalRows_Recob = mysql_num_rows($Recob);
		if ($row_Recob['csum'] >= $apud_a) {
			$new_ob=$row_Recob['csum']-$apud_a;
			$onote="註冊扣值, (".$pud_n.")<br/>帳號：".$newuser;

			mysql_select_db($database_sc, $sc);
			$insertCommand13="INSERT INTO o_cash (number, cout, csum, note, date, time) VALUES ('$snumber', '$notpay', '$new_ob', '$onote', '$date', '$time')"; 
			mysql_query($insertCommand13,$sc);
			$insert_c_cash="INSERT INTO c_cash (number, cout, csum, note, date, time, sncode) VALUES ('$number', '$notpay', '$notpay_c','$onote', '$date', '$time', '$sncode')";
			mysql_query($insert_c_cash,$sc);
			
		} else {
			header(sprintf("Location: /cmg/life_link/new_account-1.php?err=我的註冊積分不足"));
			exit;
		}
		

		
		
		
	}else{
		
		//正常入單 扣關係人註冊積分
		$query_Recob = sprintf("SELECT * FROM o_cash WHERE number='$snumber' ORDER BY id DESC");// 
		$Recob = mysql_query($query_Recob, $sc) or die(mysql_error());
		$row_Recob = mysql_fetch_assoc($Recob);
		$totalRows_Recob = mysql_num_rows($Recob);
		if ($row_Recob['csum'] >= $apud_a) {
			$new_ob=$row_Recob['csum']-$apud_a;
			$onote="註冊扣值, (".$pud_n.")<br/>帳號：".$newuser;

			mysql_select_db($database_sc, $sc);
			$insertCommand13="INSERT INTO o_cash (number, cout, csum, note, date, time) VALUES ('$snumber', '$pud_p', '$new_ob', '$onote', '$date', '$time')"; 
			mysql_query($insertCommand13,$sc);
			
		} else {
			header(sprintf("Location: /cmg/life_link/new_account-1.php?err=我的註冊積分不足"));
			exit;
		}
	}
    //
	$gk=3;unset($gg);$gg=array(300,150,100);$gi=0;$ga=$newuser;$date=date("Y-m-d");$time=date("H:i:s");
	while ($gk != 0) {
		mysql_select_db($database_sc, $sc);
        $query_Recb3 = sprintf("SELECT * FROM memberdata WHERE m_username = '$ga'");//
        $Recb3 = mysql_query($query_Recb3, $sc) or die(mysql_error());
        $row_Recb3 = mysql_fetch_assoc($Recb3);
        $totalRows_Recb3 = mysql_num_rows($Recb3);
	    $bnum=$row_Recb3['number'];//echo $bnum;exit;
		mysql_select_db($database_sc, $sc);
        $query_Recr2 = sprintf("SELECT * FROM r_cash WHERE number = '$bnum' ORDER BY id DESC");
        $Recr2 = mysql_query($query_Recr2, $sc) or die(mysql_error());
        $row_Recr2 = mysql_fetch_assoc($Recr2);
        $totalRows_Recr2 = mysql_num_rows($Recr2);
		$ggv=$gg[$gi];if ($totalRows_Recr2 != 0) {$gs=$row_Recr2['csum'];} else {$gs=0;}
		$new_ggv=$gs+$ggv;//echo $ggv,"##",$gs,"<br/>";
		$y_note="粉絲加入贈紅利".$ggv;
		$sncode=$bnum."-".date("ymdhis");

		$gold_f=$ggv;$glevel=6;$at=1;
	    $fnote="粉絲加入贈紅利".$ggv;
	    
        $insertCommand15="INSERT INTO gold_m (number, year, moom, day, z, g, note, level, at, date, time, sncode) VALUES ('$bnum', '$year', '$moom', '$day', '$z', '$gold_f', '$fnote', '$glevel', '$at', '$date', '$time', '$sncode')"; 
        mysql_query($insertCommand15,$sc);
		
		$query_r = sprintf("SELECT * FROM gold_m WHERE number = '$bnum' ORDER BY id DESC");//
        $Recbr = mysql_query($query_r, $sc) or die(mysql_error());
        $row_Recbr = mysql_fetch_assoc($Recbr);
		$gold_id =$row_Recbr['id'];
		
		$insertCommand13="INSERT INTO r_cash (number, cin, csum, note, date, time, gold_id) VALUES ('$bnum', '$ggv', '$new_ggv', '$y_note', '$date', '$time', '$gold_id')"; 
        mysql_query($insertCommand13,$sc);
		$gk--;$gi++;if ($row_Recb3['fname'] != "") {$ga=$row_Recb3['fname'];} else {break;}
		}
	//

	mysql_select_db($database_sc, $sc);

    $insertCommand3="INSERT INTO bank (number, coc, phone, email) VALUES ('$number', '$coc', '$m_callphone', '$m_email')"; 

    mysql_query($insertCommand3,$sc);

	
	if($pudid >=4)
	{
		$update11="UPDATE memberdata SET assessment=1 WHERE number = '$fnumber'";
		mysql_select_db($database_sc, $sc);
		$Result11 = mysql_query($update11, $sc) or die(mysql_error());

	}
	//infd
	if ($pudid >= 5) {
	//推薦累計
	mysql_select_db($database_sc, $sc);
	$query_Recmem_f = sprintf("SELECT * FROM memberdata WHERE m_username='$fuser'");
	$Recmem_f = mysql_query($query_Recmem_f, $sc) or die(mysql_error());
	$row_Recmem_f = mysql_fetch_assoc($Recmem_f);
	$totalRows_Recmem_f = mysql_num_rows($Recmem_f);
	$new_f_tog=$row_Recmem_f['f_tog']+1;
	$update11="UPDATE memberdata SET f_tog='$new_f_tog' WHERE m_username = '$fuser'";
	mysql_select_db($database_sc, $sc);
	$Result11 = mysql_query($update11, $sc) or die(mysql_error());
	//
		//fd-number

	mysql_select_db($database_sc, $sc);$bo="boss";

    $query_Reci = sprintf("SELECT * FROM admin WHERE username='$bo'");

    $Reci = mysql_query($query_Reci, $sc) or die(mysql_error());

    $row_Reci = mysql_fetch_assoc($Reci);

    $num_box=$row_Reci['fd_box'];

    $num_z=$row_Reci['fd_m'];

    if(date("m") != $num_z) {

	   $numz=date("m");

	   $update11="UPDATE admin SET fd_m='$numz' WHERE username='$bo'";

       mysql_select_db($database_sc, $sc);

       $Result11 = mysql_query($update11, $sc) or die(mysql_error());

	   $num_box=1;

	   }

    if ($num_box == 10000) {echo "設定值巳超過9999單號，請洽系統工程師。";exit;}

    if ($num_box < 10) {$fdnumber="SN".date("ymd")."000".$num_box;$fdcard="f".date("ym")."000".$num_box;}

    if ($num_box > 9 && $num_box < 100) {$fdnumber="SN".date("ymd")."00".$num_box;$fdcard="f".date("ym")."00".$num_box;}

    if ($num_box < 1000 && $num_box > 99) {$fdnumber="SN".date("ymd")."0".$num_box;$fdcard="f".date("ym")."0".$num_box;}

	if ($num_box < 10000 && $num_box > 999) {$fdnumber="SN".date("ymd").$num_box;$fdcard="f".date("ym").$num_box;}

	$new_num_box=$num_box+1;

    $update11="UPDATE admin SET fd_box='$new_num_box' WHERE username='$bo'";

    mysql_select_db($database_sc, $sc);

    $Result11 = mysql_query($update11, $sc) or die(mysql_error());

		//我系大公排

	if ($pudid < 8) {
			//推薦人位置
			$select_position = "SELECT * FROM fd WHERE number ='$fnumber'  ORDER BY id ASC" ;
			$query_position = mysql_query($select_position, $sc) or die(mysql_error());
			$row_position = mysql_fetch_assoc($query_position);
			$p_position = $row_position["filling_position"];
			//判斷入單位置
			$m_fuser = $fnumber;
			do{
				$select_position = "SELECT * FROM fd WHERE number ='$m_fuser'" ;
				$query_position = mysql_query($select_position, $sc) or die(mysql_error());
				$row_position = mysql_fetch_assoc($query_position);
				$fposition = $row_position["filling_position"];
				$fcard = $row_position["card"];
				if(empty($fposition))
				{
					$select_position = "SELECT * FROM memberdata WHERE number ='$m_fuser'" ;
					$query_position = mysql_query($select_position, $sc) or die(mysql_error());
					$row_position = mysql_fetch_assoc($query_position);
					$m_fuser = $row_position["m_fuser"];
					$m_guser = $row_position["m_guser"];
					if(empty($m_fuser)){
						$m_fuser = $m_guser;
					}
				}
			}while(empty($fposition));
			//
			//掃描空位置
			$objQueue = new Queue;
			$filling_position = $fposition;

			do{
				
				if(empty($index))
				{
					$objQueue->EnQueue($filling_position);
					
					
				}else{
					$index = $index*2;
					$objQueue->EnQueue($index);
					$index = $index+1;
					
					$objQueue->EnQueue($index);
				
				}
				
				$index = $objQueue->DeQueue();
				
				 $scanning ="SELECT * FROM fd WHERE filling_position = '$index'";
				 $query_scanning = mysql_query($scanning, $sc) or die(mysql_error());
				 $num_scanning = mysql_num_rows($query_scanning);
				
				
			}while ( $num_scanning >0 );
			
			
			if($index % 2 ==0){$gw = 'L';}else{$gw = 'R';};
			$nyear = $year +1;
			$gindex = floor($index/2); //上層的位置
			$select_gposition = "SELECT * FROM fd WHERE filling_position ='$gindex'";
			$query_gposition = mysql_query($select_gposition, $sc) or die(mysql_error());
			$row_gposition = mysql_fetch_assoc($query_gposition);
			$g_user = $row_gposition['card']; //上層的card
			
			$query_Recxf = sprintf("SELECT * FROM fd WHERE number = '$number' && card='$fdcard' && gtow='$gw'");

            $Recxf = mysql_query($query_Recxf, $sc) or die(mysql_error());

            $row_Recxf = mysql_fetch_assoc($Recxf);

            $totalRows_Recxf = mysql_num_rows($Recxf);
		//
		if ($totalRows_Recxf == 0) {
			//新人福袋
			$fd_amount = $apud_a;
			$insertCommand13="INSERT INTO fd (number, card, name, c_fuser, c_guser, gtow, filling_position, fd_amount, year, moom, day, end_y, end_m, end_d, date, time, fnumber) VALUES ('$number', '$fdcard', '$m_nick', '$fcard', '$g_user', '$gw', '$index','$fd_amount', '$year', '$moom', '$day', '$nyear', '$moom', '$day', '$date', '$time', '新人福袋')"; 
			mysql_query($insertCommand13,$sc);
			//入單 out
			$objout = new out;
			do{
				if(empty($s))
				{
					$loop_out = $objout->is_out($fposition ,1);
				}else{
					$loop_out = $objout->is_out($loop_out,1);
				}
				$s++;
			}while($loop_out);
			//
			
			//補球 out
			do{
				if(empty($x))
				{
					$loop_out = $objout->is_out($index,0);
				}else{
					$loop_out = $objout->is_out($loop_out,0);
				}
				$x++;
			}while($loop_out);
			//

			//入單補營運球
			
			$promotions_odj = new Promotions;
			$promotions_odj->join_event($index);
			//
			//推廣補球

			$promotions_odj = new Promotions;
			$promotions_odj-> promoting_event($p_position,$index);
			/////
			
		}
///////////////////////
	}
	

		if ($pudid >= 8) {

			mysql_select_db($database_sc, $sc);

            $query_Recmfd = sprintf("SELECT * FROM fd2 WHERE number='$fnumber' ORDER BY id");//  DESC

            $Recmfd = mysql_query($query_Recmfd, $sc) or die(mysql_error());

            $row_Recmfd = mysql_fetch_assoc($Recmfd);

	        $totalRows_Recmfd = mysql_num_rows($Recmfd);

	        if ($totalRows_Recmfd != 0) {$mfdcard=$row_Recmfd['card'];} else {$mfdcard="dxxxx1";} 

			$xgu="";

			$x2=$mfdcard;$xa=0;unset($xbu);$xbi=0;$xbj=0;//echo $x2;exit;

			while ($xa == 0) {

				mysql_select_db($database_sc, $sc);

				$query_Recx2 = sprintf("SELECT * FROM fd2 WHERE c_guser = '$x2' ORDER BY gtow");

				$Recx2 = mysql_query($query_Recx2, $sc) or die(mysql_error());

				$row_Recx2 = mysql_fetch_assoc($Recx2);

				$totalRows_Recx2 = mysql_num_rows($Recx2);

				if ($totalRows_Recx2 < 2) {$xgu=$x2;$xa=1;} else {do {$xbu[$xbi]=$row_Recx2['card'];$xbi++;} while ($row_Recx2 = mysql_fetch_assoc($Recx2));$x2=$xbu[$xbj];$xbj++;}

				}

				mysql_select_db($database_sc, $sc);

				$query_Recgg = sprintf("SELECT * FROM fd2 WHERE c_guser='$xgu'");

				$Recgg = mysql_query($query_Recgg, $sc) or die(mysql_error());

				$row_Recgg = mysql_fetch_assoc($Recgg);

				$totalRows_Recgg = mysql_num_rows($Recgg);

				if ($totalRows_Recgg == 0) {$gw="L";} else {if ($row_Recgg['gtow'] == "L") {$gw="R";} else {$gw="L";}}

				$nyear=$year+1;

				mysql_select_db($database_sc, $sc);

				$query_Recxf = sprintf("SELECT * FROM fd2 WHERE number = '$number' && card='$fdcard' && gtow='$gw'");

				$Recxf = mysql_query($query_Recxf, $sc) or die(mysql_error());

				$row_Recxf = mysql_fetch_assoc($Recxf);

				$totalRows_Recxf = mysql_num_rows($Recxf);

			if ($totalRows_Recxf == 0) {

				mysql_select_db($database_sc, $sc);

				$insertCommand13="INSERT INTO fd2 (number, card, name, c_fuser, c_guser, gtow, year, moom, day, end_y, end_m, end_d, date, time) VALUES ('$number', '$fdcard', '$m_nick', '$mfdcard', '$xgu', '$gw', '$year', '$moom', '$day', '$nyear', '$moom', '$day', '$date', '$time')"; 

				mysql_query($insertCommand13,$sc);

			}

		}

		//////

	}//3

	//進水庫
	$obj_reservoir = new reservoir;
	$obj_reservoir->new_in($number,$card,$pudid,$Tnumber,$notpay);
	ob_end_flush();
///////////////////////////////////////////////////////
	$_SESSION['sn']=$sn;$_SESSION['gfus']=$fnumber;$_SESSION['newnr']=$number;$_SESSION['pudid']=$pudid;$_SESSION['fdcard']=$fdcard;
	
	?>

<script type="text/javascript">document.location.href="x_g_f.php";</script>