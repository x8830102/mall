    <div class="top-bar hidden-xs">
        <div class="top_img col-lg-3 col-md-3 col-sm-4 col-xs-12" align="center">
            <a href="index.php"><img src="img/life-link_logo.png" width="230px" alt="串門子雲端"></a>
        </div>
        <div class="top_img col-lg-8 col-md-8 col-sm-7  hidden-xs" align="center">
            <img src="img/slogn1.png" width="370px" alt="LIFE LINK在地生活，緊密串聯">
        </div>
    </div>
